import openpyxl
from typing import Dict, Any

def log_test_run_to_benchmark(
    excel_path: str,
    test_id: str,
    extraction_count: int,
    correct_count: int,
    citation_accuracy: float,
    f1_score: float,
    hallucination_free: bool,
    query_latency_sec: float
):
    """
    Updates the Validation Test Bench sheet in the Excel workbook 
    with live execution metrics for a given Test ID.
    """
    wb = openpyxl.load_workbook(excel_path)
    
    if "Validation Test Bench" not in wb.sheetnames:
        raise ValueError("Sheet 'Validation Test Bench' not found in workbook.")
        
    ws = wb["Validation Test Bench"]
    
    # Locate row for test_id (rows 7 through 20)
    target_row = None
    for r in range(7, 21):
        cell_val = ws.cell(row=r, column=1).value
        if cell_val == test_id:
            target_row = r
            break
            
    if not target_row:
        raise ValueError(f"Test ID '{test_id}' not found in benchmark rows.")

    # Update actual metric columns
    ws.cell(row=target_row, column=5, value=extraction_count)     # Extraction Count
    ws.cell(row=target_row, column=6, value=correct_count)        # Correct Extracted
    ws.cell(row=target_row, column=8, value=citation_accuracy)   # Citation Accuracy
    ws.cell(row=target_row, column=9, value=f1_score)            # F1 Score
    ws.cell(row=target_row, column=10, value=1 if hallucination_free else 0) # Hallucination Free
    ws.cell(row=target_row, column=11, value=query_latency_sec)  # Query Latency

    wb.save(excel_path)
    print(f" Successfully updated {test_id} in {excel_path}")
