import json
from typing import List, Optional
from pydantic import BaseModel, Field

class EntityExtraction(BaseModel):
    entity_name: str = Field(description="The primary name or title of the extracted entity")
    entity_type: str = Field(description="Category: DOSAGE, ELIGIBILITY_CRITERIA, BIOMARKER, COHORT_SIZE, ENDPOINT, DRUG")
    exact_quote: str = Field(description="The EXACT raw substring quote from the text chunk")
    confidence: float = Field(default=1.0, description="Extraction confidence score between 0.0 and 1.0")

class ClinicalChunkExtraction(BaseModel):
    chunk_id: str = Field(description="Identifier of the source chunk")
    entities: List[EntityExtraction] = Field(default_factory=list, description="List of clinical entities extracted from the chunk")

def generate_extraction_prompt(chunk_text: str, chunk_id: str) -> str:
    """
    Generates a structured extraction prompt enforcing JSON output matching Pydantic schema.
    """
    schema_json = ClinicalChunkExtraction.model_json_schema()
    
    prompt = f"""
You are a precision clinical data extraction agent analyzing medical literature on Sarcoma/Chordoma.
Extract all relevant clinical parameters from the following text chunk.

STRICT REQUIREMENTS:
1. For 'exact_quote', you MUST provide the exact, verbatim substring as it appears in the text chunk. Do not paraphrase.
2. Return ONLY a valid JSON object matching the following JSON Schema:

{json.dumps(schema_json, indent=2)}

SOURCE TEXT CHUNK [{chunk_id}]:
"""{chunk_text}"""
"""
    return prompt

def validate_extraction_response(raw_llm_json: str) -> ClinicalChunkExtraction:
    """
    Parses and validates the raw JSON response against the Pydantic schema.
    """
    parsed_data = json.loads(raw_llm_json)
    return ClinicalChunkExtraction(**parsed_data)
