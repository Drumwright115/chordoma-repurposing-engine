import re
from typing import List, Dict, Any

def verify_and_filter_hallucinations(
    extracted_entities: List[Dict[str, Any]], 
    source_chunk_text: str
) -> Dict[str, Any]:
    """
    Verifies every extracted entity against the raw source text chunk.
    Filters out any entity whose exact quote cannot be matched in the source text,
    eliminating hallucinations and calculating precision metrics.
    """
    verified_entities = []
    rejected_entities = []

    # Normalize source text whitespace for robust comparison
    normalized_source = " ".join(source_chunk_text.split())

    for entity in extracted_entities:
        raw_quote = entity.get("exact_quote", "")
        normalized_quote = " ".join(raw_quote.split())

        # Check for verbatim or normalized exact match in source text
        if normalized_quote and normalized_quote in normalized_source:
            verified_entities.append(entity)
        else:
            rejected_entities.append({
                "entity": entity,
                "reason": "Exact quote not found in source chunk (hallucination/paraphrase flag)"
            })

    total_extracted = len(extracted_entities)
    verified_count = len(verified_entities)
    hallucination_count = len(rejected_entities)
    
    precision_score = (verified_count / total_extracted) if total_extracted > 0 else 1.0

    return {
        "verified_entities": verified_entities,
        "rejected_entities": rejected_entities,
        "hallucination_free": hallucination_count == 0,
        "precision_score": precision_score,
        "metrics": {
            "total_extracted": total_extracted,
            "verified_count": verified_count,
            "rejected_count": hallucination_count
        }
    }
