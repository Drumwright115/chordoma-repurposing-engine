import json
from pypdf import PdfReader

def parse_pdf_with_character_spans(pdf_path, chunk_size=500, overlap=50):
    """
    Reads a PDF document, maintains a running global character counter, 
    and returns text chunks with precise start/end character offsets.
    """
    reader = PdfReader(pdf_path)
    chunks = []
    global_offset = 0

    for page_idx, page in enumerate(reader.pages, start=1):
        page_text = page.extract_text() or ""
        page_len = len(page_text)
        
        # Slide through page text to create overlapping chunks
        start_in_page = 0
        while start_in_page < page_len:
            end_in_page = min(start_in_page + chunk_size, page_len)
            chunk_str = page_text[start_in_page:end_in_page]
            
            # Global character coordinates across the whole document
            char_start = global_offset + start_in_page
            char_end = global_offset + end_in_page

            chunks.append({
                "chunk_id": f"p{page_idx}_c{start_in_page}",
                "page": page_idx,
                "text": chunk_str,
                "char_start": char_start,
                "char_end": char_end
            })

            if end_in_page == page_len:
                break
            start_in_page += (chunk_size - overlap)

        global_offset += page_len

    return chunks, reader

def Map_extracted_entity_to_source_span(extracted_entity, chunk):
    """
    Calculates exact global character span coordinates for an extracted entity quote.
    """
    quote = extracted_entity.get("exact_quote", "").strip()
    chunk_text = chunk["text"]
    
    quote_offset_in_chunk = chunk_text.find(quote)
    if quote_offset_in_chunk != -1:
        entity_char_start = chunk["char_start"] + quote_offset_in_chunk
        entity_char_end = entity_char_start + len(quote)
    else:
        # Fallback to chunk boundary if exact quote string isn't matched
        entity_char_start = chunk["char_start"]
        entity_char_end = chunk["char_end"]

    node_metadata = {
        "entity_name": extracted_entity.get("entity_name"),
        "entity_type": extracted_entity.get("entity_type"),
        "exact_quote": quote,
        "page": chunk["page"],
        "char_start": entity_char_start,
        "char_end": entity_char_end,
        "chunk_id": chunk["chunk_id"]
    }
    
    return node_metadata
